在微信小程序搜索“悬笔e绝”，或者用微信扫描下面的二维码哦</br>
![Image text](https://github.com/yllg/WXxcx/blob/master/readme%20img/9.jpeg)
 </br>
我的个人微信公众号--悬笔e绝，欢迎关注哈
![Image text](https://github.com/yllg/WXxcx/blob/master/readme%20img/10.jpeg)
</br>
（1）欢迎页：这个logo是当年念大学给社团做的logo，苦学了整整一周的PS啊。。。</br>
![Image text](https://github.com/yllg/WXxcx/blob/master/readme%20img/1.png)
 </br>
（2）首页：轮播头图，天气，豆瓣电影正在热映</br>
![Image text](https://github.com/yllg/WXxcx/blob/master/readme%20img/2.png)
 </br>
（3）全国城市切换页</br>
![Image text](https://github.com/yllg/WXxcx/blob/master/readme%20img/3.png)
 </br>
（4）天气详情页</br>
![Image text](https://github.com/yllg/WXxcx/blob/master/readme%20img/4.png)
</br>
（5）地图周边服务</br>
![Image text](https://github.com/yllg/WXxcx/blob/master/readme%20img/5.png)
 </br>
（6）豆瓣电影</br>
![Image text](https://github.com/yllg/WXxcx/blob/master/readme%20img/6.png)
 </br>
（7）热点新闻</br>
![Image text](https://github.com/yllg/WXxcx/blob/master/readme%20img/7.png)
</br>
（8）更多页面</br>
![Image text](https://github.com/yllg/WXxcx/blob/master/readme%20img/8.png)
</br>

四.写在最后</br>
1.推荐几个小程序开发的资料</br>
（1）知乎一篇小程序的资料：</br>
https://www.zhihu.com/question/50907897  </br>
（2）小程序社区</br>
http://www.wxapp-union.com/portal.php  </br>
（3）极乐小程序商店</br>
http://store.dreawer.com/  </br>

 

